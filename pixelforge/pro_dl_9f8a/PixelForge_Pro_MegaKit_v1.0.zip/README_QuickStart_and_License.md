# PixelForge Pro Mega-Kit v1.0

Thank you for supporting independent game tool development!

## Included in This Commercial Bundle
1. **`PixelForge_Studio_Offline_Pro/index.html`** — Double-click in any modern browser (100% offline, zero internet required) to generate 2D Tangent Normal Maps with live 3D point-light preview, auto-slice irregular sprite sheets into Godot 4 / Unity / Phaser 3 JSON atlases, synthesize unlimited 16-bit WAV sound effects, and bake pixel outlines/palettes.
2. **`120_Retro_Game_SFX_WAV/`** — 120 crisp 44.1kHz 16-bit PCM `.wav` sound effects across 8 game categories (Coins, Jumps, Lasers, Explosions, Damage Hits, Power-Ups, UI Clicks, Retro Synths).
3. **`2D_Shaders_Godot4_and_Unity/`** — Production-ready 2D shaders:
   - Godot 4: `hit_flash_2d.gdshader`, `pixel_outline_2d.gdshader`, `dissolve_burn_2d.gdshader`, `crt_retro_screen.gdshader`
   - Unity: `SpriteHitFlashAndOutline.shader`, `SpriteDissolveBurn.shader`

## Commercial License
- **Permitted**: Unlimited use in commercial & non-commercial games, client projects, prototypes, game jams, and videos without attribution.
- **Not Permitted**: Redistributing or reselling the raw unmodified bundle itself as a competing asset pack.
