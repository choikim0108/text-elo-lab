window.PIXELFORGE_CONFIG = {
  productName: "PixelForge Studio Pro",
  edition: "PRO MEGA-KIT",
  isProUnlocked: true
};
