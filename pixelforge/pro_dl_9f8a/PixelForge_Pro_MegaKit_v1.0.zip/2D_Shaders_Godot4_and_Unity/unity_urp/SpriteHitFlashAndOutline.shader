Shader "PixelForgePro/2D/SpriteHitFlashAndOutline"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _FlashColor ("Hit Flash Color", Color) = (1,1,1,1)
        _FlashAmount ("Flash Amount", Range(0,1)) = 0.0
        _OutlineColor ("Outline Color", Color) = (0.05, 0.95, 0.85, 1)
        _OutlineEnabled ("Enable Outline (0 or 1)", Range(0,1)) = 1.0
        _OutlineThickness ("Outline Pixel Width", Range(0,4)) = 1.0
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "IgnoreProjector"="True"
            "RenderType"="Transparent"
            "PreviewType"="Plane"
            "CanUseSpriteAtlas"="True"
        }

        Cull Off
        Lighting Off
        ZWrite Off
        Blend One OneMinusSrcAlpha

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata_t
            {
                float4 vertex   : POSITION;
                float4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            struct v2f
            {
                float4 vertex   : SV_POSITION;
                fixed4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            sampler2D _MainTex;
            float4 _MainTex_TexelSize;
            fixed4 _Color;
            fixed4 _FlashColor;
            float _FlashAmount;
            fixed4 _OutlineColor;
            float _OutlineEnabled;
            float _OutlineThickness;

            v2f vert(appdata_t IN)
            {
                v2f OUT;
                OUT.vertex = UnityObjectToClipPos(IN.vertex);
                OUT.texcoord = IN.texcoord;
                OUT.color = IN.color * _Color;
                return OUT;
            }

            fixed4 frag(v2f IN) : SV_Target
            {
                fixed4 c = tex2D(_MainTex, IN.texcoord) * IN.color;

                if (_OutlineEnabled > 0.5 && c.a < 0.1)
                {
                    float2 px = _MainTex_TexelSize.xy * _OutlineThickness;
                    float up = tex2D(_MainTex, IN.texcoord + float2(0, px.y)).a;
                    float down = tex2D(_MainTex, IN.texcoord - float2(0, px.y)).a;
                    float right = tex2D(_MainTex, IN.texcoord + float2(px.x, 0)).a;
                    float left = tex2D(_MainTex, IN.texcoord - float2(px.x, 0)).a;
                    float neighbor = max(max(up, down), max(left, right));
                    if (neighbor >= 0.1)
                    {
                        fixed4 oc = _OutlineColor;
                        oc.rgb *= oc.a;
                        return oc;
                    }
                }

                c.rgb = lerp(c.rgb, _FlashColor.rgb, saturate(_FlashAmount));
                c.rgb *= c.a;
                return c;
            }
            ENDCG
        }
    }
}
