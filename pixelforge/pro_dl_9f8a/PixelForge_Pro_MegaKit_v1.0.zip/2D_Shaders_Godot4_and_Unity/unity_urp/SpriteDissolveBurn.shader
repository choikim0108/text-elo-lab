Shader "PixelForgePro/2D/SpriteDissolveBurn"
{
    Properties
    {
        [PerRendererData] _MainTex ("Sprite Texture", 2D) = "white" {}
        _Color ("Tint", Color) = (1,1,1,1)
        _Dissolve ("Dissolve Progress", Range(0,1)) = 0.0
        _EdgeWidth ("Burn Edge Width", Range(0.01, 0.25)) = 0.08
        _BurnInner ("Burn Inner Color", Color) = (1, 0.92, 0.25, 1)
        _BurnOuter ("Burn Outer Color", Color) = (1, 0.22, 0.05, 1)
        _PixelGrid ("Pixel Grid Resolution", Range(16, 512)) = 64
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "IgnoreProjector"="True"
            "RenderType"="Transparent"
            "PreviewType"="Plane"
            "CanUseSpriteAtlas"="True"
        }

        Cull Off
        Lighting Off
        ZWrite Off
        Blend One OneMinusSrcAlpha

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            struct appdata_t
            {
                float4 vertex   : POSITION;
                float4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            struct v2f
            {
                float4 vertex   : SV_POSITION;
                fixed4 color    : COLOR;
                float2 texcoord : TEXCOORD0;
            };

            sampler2D _MainTex;
            fixed4 _Color;
            float _Dissolve;
            float _EdgeWidth;
            fixed4 _BurnInner;
            fixed4 _BurnOuter;
            float _PixelGrid;

            float hash21(float2 p)
            {
                p = frac(p * float2(123.34, 456.21));
                p += dot(p, p + 45.32);
                return frac(p.x * p.y);
            }

            v2f vert(appdata_t IN)
            {
                v2f OUT;
                OUT.vertex = UnityObjectToClipPos(IN.vertex);
                OUT.texcoord = IN.texcoord;
                OUT.color = IN.color * _Color;
                return OUT;
            }

            fixed4 frag(v2f IN) : SV_Target
            {
                fixed4 c = tex2D(_MainTex, IN.texcoord) * IN.color;
                float2 snapped = floor(IN.texcoord * _PixelGrid) / _PixelGrid;
                float n = hash21(snapped);

                clip(n - _Dissolve);

                float dist = n - _Dissolve;
                if (dist < _EdgeWidth && _Dissolve > 0.001)
                {
                    float t = saturate(dist / _EdgeWidth);
                    fixed4 burn = lerp(_BurnOuter, _BurnInner, 1.0 - t);
                    c.rgb = burn.rgb;
                }

                c.rgb *= c.a;
                return c;
            }
            ENDCG
        }
    }
}
